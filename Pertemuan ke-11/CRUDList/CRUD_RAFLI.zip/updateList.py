
def editData(databaseKaryawan):
    if len(databaseKaryawan) == 0:
        print('Data masih kosong!!!')
        print()
    else:
        namaKaryawan = input('Masukkan nama karyawan yang ingin di edit : ').upper()
        for karyawan in databaseKaryawan:
                if namaKaryawan == karyawan[0]:
                    print(f'Data ditemukan {karyawan} silahkan edit data tersebut')
                    karyawan.clear()
                    namaKaryawanBaru = input('Masukkan Nama karyawan : ').upper()
                    umur = int(input('Masukkan umur karyawan : '))
                    golongan = int(input('Masukkan golongan karyawan : '))
                    karyawan.append(namaKaryawanBaru)
                    karyawan.append(umur)
                    karyawan.append(golongan)
                    print('Data berhasil di edit')
                    print('-------------------------------------------')
                    print()
                else:
                    print('Data karyawan tidak ditemukan.')
                    print()
                