def format_uang(angka):
    return f"{angka:,}".replace(",", ".")

def dekorasi(jml):
    print("=" * jml)
    
def dekorasiGaris(jml):
     print("-" * jml)
    
